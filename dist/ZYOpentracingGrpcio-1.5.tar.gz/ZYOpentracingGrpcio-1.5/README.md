# grpc-opentracing
grpc-opentracing自用

使用环境Python、grpc、jaeger

在使用[grpc-opentracing](https://github.com/grpc-ecosystem/grpc-opentracing/tree/master/python)发送请求报错或者无法发送到jaeger；修复后提交自用

当前使用版本：

python 3.8

jaeger-client       4.8.0

'opentracing>=2.4.0'

 'grpcio>=1.63.0'

'six>=1.16.0'

安装方式

```bash
pip install ZYOpentracingGrpcio
```

